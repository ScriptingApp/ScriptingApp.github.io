# DeviceServices

`DeviceServices` 是 App 脚本主线程的全局 API，**不需要从 `scripting` 或 Node 包导入**。它连接普通 TCP 端点，交换带长度前缀的 XML/binary plist 消息。脚本提供主机、端口和应用消息；连接不提供 TLS。

## plist 消息

以下完整示例需要将地址替换为你自己的 plist 回显服务：

```ts
async function main() {
  const connection = await DeviceServices.connect({
    host: "192.168.1.10", // 替换为实际服务地址。
    port: 12345,
    timeout: 10000,
  })
  try {
    await connection.writePlist({
      Request: "Echo",
      Payload: new Uint8Array([1, 2, 3]),
      CreatedAt: new Date(),
    }, { format: "binary" })
    console.log(await connection.readPlist({ timeout: 10000 }))
  } finally {
    await connection.close()
  }
}
main().catch(console.error)
```

`connect` 使用普通 TCP。每条消息由四字节大端长度和 XML/binary plist 组成；发送默认 binary。值支持字符串、有限数字、布尔值、`Date`、`Uint8Array`、数组和字符串键对象。不支持 null、undefined、非安全整数、循环引用和函数。新消息头之前正常 EOF 返回 `null`；消息截断、格式错误会拒绝并关闭连接。

`maximumFrameBytes` 默认 1 MiB，范围 1024–8388608；嵌套最多 64 层、16384 个节点。超时单位毫秒，默认 30000，范围 1–300000。IO 超时或取消后应重新连接；同一连接每次只执行一个操作。

## 错误与清理

错误通过 `code` 标识，包括 `ERR_DEVICE_CLOSED`、`ERR_DEVICE_BUSY`、`ERR_DEVICE_PROTOCOL`、`ERR_DEVICE_TIMEOUT`、`ERR_DEVICE_CANCELLED`、`ERR_DEVICE_FRAME_LIMIT` 和 `ERR_INVALID_ARG_VALUE`。按错误码处理，不匹配本地化文本。`close()` 会释放挂起 IO，可用于清理连接。
