`Device` 命名空间提供对当前设备硬件、系统环境、语言区域、屏幕信息、电池状态、方向感知、接近传感器以及网络接口等信息的访问能力，并提供相关状态变化的监听接口。

该 API 主要用于根据设备环境动态调整 UI、行为逻辑或系统能力使用方式。

---

## 内存

以下只读属性通过全局 `Device` 直接访问，无需导入。数值统一以**字节**为单位，每次访问时读取。

| 属性 | 类型 | 含义 |
| --- | --- | --- |
| `physicalMemory` | `number` | 系统报告的设备物理内存总量，不是当前进程的内存上限。 |
| `processMemoryUsage` | `number \| null` | 当前宿主进程的内存占用（`phys_footprint`）。查询失败或系统返回的数据不足时为 `null`。 |
| `availableMemory` | `number` | 系统估计当前进程距离其当前内存上限还剩多少字节，不是设备全局空闲内存。 |

`processMemoryUsage` 包含宿主本身以及同进程中其他脚本的内存，不能单独统计一个脚本的 JavaScript 堆。在小组件或其他扩展中，它读取的是该扩展进程，不是主 App，也不是所有 App 进程的合计。Footprint 包含压缩内存的记账，与驻留内存的口径不同。

`availableMemory` 仅供参考，数值可能立即变化，系统也可能调整进程的内存上限。需要时应重新读取。`0` 可能表示进程已经达到或超过上限，也可能表示系统无法提供该进程的 App 内存额度。它不保证分配成功，也不应将可用内存或物理内存总量作为分配目标。

建议在关键步骤或以适当间隔读取内存，避免高频循环查询。将字节除以 `1024 * 1024` 可转换为 MiB。

```ts
import { Script } from "scripting"

const usage = Device.processMemoryUsage
console.log("设备物理内存（MiB）：", Device.physicalMemory / 1024 / 1024)
console.log("进程内存占用（MiB）：", usage === null ? "不可用" : usage / 1024 / 1024)
console.log("进程可用内存（MiB）：", Device.availableMemory / 1024 / 1024)
Script.exit()
```

---

## Orientation

表示设备当前的物理朝向。

```ts
type Orientation =
  | "portrait"
  | "portraitUpsideDown"
  | "landscapeLeft"
  | "landscapeRight"
  | "faceUp"
  | "faceDown"
  | "unknown"
```

### 说明

* `portrait`：竖屏，Home 键在下（或标准竖屏方向）
* `portraitUpsideDown`：竖屏倒置
* `landscapeLeft`：横屏，设备向左旋转
* `landscapeRight`：横屏，设备向右旋转
* `faceUp`：设备平放，屏幕朝上
* `faceDown`：设备平放，屏幕朝下
* `unknown`：无法确定方向

---

## InterfaceOrientation

表示App UI 的可旋转方向

```ts
type InterfaceOrientation =
  | "portrait"
  | "portraitUpsideDown"
  | "landscape"
  | "landscapeLeft"
  | "landscapeRight"
  | "all"
  | "allButUpsideDown"
```

### 说明

* `portrait`：竖屏，Home 键在下（或标准竖屏方向）
* `portraitUpsideDown`：竖屏倒置
* `landscape`：横屏，设备向左旋转
* `landscapeLeft`：横屏，设备向左旋转
* `landscapeRight`：横屏，设备向右旋转
* `all`：所有可旋转方向
* `allButUpsideDown`：除了竖屏，所有可旋转方向

---

## NetworkInterface

描述单个网络接口地址的信息。

```ts
type NetworkInterface = {
  address: string
  netmask: string | null
  family: "IPv4" | "IPv6"
  mac: string | null
  isInternal: boolean
  cidr: string | null
}
```

### 字段说明

* `address`：IP 地址
* `netmask`：子网掩码
* `family`：地址族，IPv4 或 IPv6
* `mac`：MAC 地址（部分系统或接口可能为 null）
* `isInternal`：是否为内部接口（如 loopback）
* `cidr`：CIDR 表示形式，例如 `192.168.1.10/24`

---

## BatteryState

表示当前电池状态。

```ts
type BatteryState = "full" | "charging" | "unplugged" | "unknown"
```

### 说明

* `full`：电量已充满
* `charging`：正在充电
* `unplugged`：未连接电源
* `unknown`：无法确定状态

---

## Device Information

### model

```ts
const model: string
```

设备型号，例如 `"iPhone"`、`"iPad"`。

---

### localizedModel

```ts
const localizedModel: string
```

本地化后的设备型号名称。

---

### appVersion / appBuildNumber

同步只读字符串，用于识别 Scripting App，扩展中的脚本也可读取。`appVersion` 对应 `CFBundleShortVersionString`，`appBuildNumber` 对应 `CFBundleVersion`。构建号保持字符串（可能含小数点或前导零）。无法读取宿主 App 时使用当前运行 bundle；字段缺失时返回空字符串。

`Device` 是注入的全局 API，直接使用，无需导入：

```ts
console.log(`Scripting ${Device.appVersion} (${Device.appBuildNumber})`)
console.log(`OS ${Device.systemVersion}`)
```

这两个字段表示 Scripting 本体的版本，与脚本自身版本、操作系统版本分别独立，不需要权限或网络访问。

---

### systemVersion

```ts
const systemVersion: string
```

当前操作系统版本号，例如 `"18.2"`。

---

### systemName

```ts
const systemName: string
```

操作系统名称，例如 `"iOS"`、`"iPadOS"`、`"macOS"`。

---

### isiPad / isiPhone

```ts
const isiPad: boolean
const isiPhone: boolean
```

指示当前设备是否为 iPad 或 iPhone。

---

### screen

```ts
const screen: {
  width: number
  height: number
  scale: number
}
```

屏幕信息：

* `width`：屏幕宽度（逻辑像素）
* `height`：屏幕高度（逻辑像素）
* `scale`：屏幕缩放比例（如 2、3）

---

## Battery & Sensors

### batteryState

```ts
const batteryState: BatteryState
```

当前电池状态。

---

### batteryLevel

```ts
const batteryLevel: number
```

当前电量百分比，范围为 `0.0` 到 `1.0`。

---

### proximityState

```ts
const proximityState: boolean
```

接近传感器状态，`true` 表示设备靠近用户（例如通话时贴近耳朵）。

---

## Orientation & Layout

### isLandscape / isPortrait / isFlat

```ts
const isLandscape: boolean
const isPortrait: boolean
const isFlat: boolean
```

* `isLandscape`：是否处于横屏
* `isPortrait`：是否处于竖屏
* `isFlat`：设备是否平放（face up / face down）

---

### orientation

```ts
const orientation: Orientation
```

当前设备物理方向。

---

### supportedInterfaceOrientations

```ts
var supportedInterfaceOrientations: InterfaceOrientation[]
```

获取和设置当前支持的旋转方向。

#### 示例

```tsx
function Page() {
  useEffect(() => {
    Device.supportedInterfaceOrientations = ["all"]
    return () => {
      Device.supportedInterfaceOrientations = Device.userConfiguredInterfaceOrientations
    }
  }, [])
  return <VStack>...</VStack>
}
```

---

### userConfiguredInterfaceOrientations

```ts
const userConfiguredInterfaceOrientations: InterfaceOrientation[]
```

获取用户配置的旋转方向。你可以使用这个值的来设置`supportedInterfaceOrientations`以恢复为默认的旋转方向。

---

## Appearance & Environment

### colorScheme

```ts
const colorScheme: ColorScheme
```

当前系统颜色模式，例如浅色或深色模式。

---

### isiOSAppOnMac

```ts
const isiOSAppOnMac: boolean
```

指示当前进程是否为运行在 macOS 上的 iPhone / iPad App（Mac Catalyst 或 iOS App on Mac）。

---

## Locale & Language

### systemLocale

```ts
const systemLocale: string
```

当前系统 Locale，例如 `"en_US"`。

---

### preferredLanguages

```ts
const preferredLanguages: string[]
```

用户偏好的语言列表，例如：

```ts
["en-US", "zh-Hans-CN"]
```

---

### systemLocales（已废弃）

```ts
const systemLocales: string[]
```

已废弃，请使用 `preferredLanguages`。

---

### systemLanguageTag

```ts
const systemLanguageTag: string
```

语言标签，例如 `"en-US"`。

---

### systemLanguageCode

```ts
const systemLanguageCode: string
```

语言代码，例如 `"en"`。

---

### systemCountryCode

```ts
const systemCountryCode: string | undefined
```

国家代码，例如 `"US"`。

---

### systemScriptCode

```ts
const systemScriptCode: string | undefined
```

书写系统代码，例如 `"Hans"`（简体中文）。

---

## Wake Lock

### isWakeLockEnabled

```ts
const isWakeLockEnabled: Promise<boolean>
```

查询当前是否启用了屏幕唤醒锁定（防止设备自动锁屏）。

---

### setWakeLockEnabled

```ts
function setWakeLockEnabled(enabled: boolean): void
```

启用或禁用 Wake Lock。

说明：

* 仅在 **Scripting App** 内可用
* 启用后可防止设备自动休眠

---

## Battery Listeners

### addBatteryStateListener

```ts
function addBatteryStateListener(
  callback: (state: BatteryState) => void
): void
```

监听电池状态变化。

---

### removeBatteryStateListener

```ts
function removeBatteryStateListener(
  callback?: (state: BatteryState) => void
): void
```

移除电池状态监听器。

* 未传入 `callback` 时将移除所有监听器

---

### addBatteryLevelListener

```ts
function addBatteryLevelListener(
  callback: (level: number) => void
): void
```

监听电量变化。

---

### removeBatteryLevelListener

```ts
function removeBatteryLevelListener(
  callback?: (level: number) => void
): void
```

移除电量监听器。

---

## Orientation Listeners

### addOrientationListener

```ts
function addOrientationListener(
  callback: (orientation: Orientation) => void
): void
```

开始监听设备方向变化。

注意事项：

* 必须先调用该方法才能接收方向变化
* 系统方向锁开启时不会生效

---

### removeOrientationListener

```ts
function removeOrientationListener(
  callback?: (orientation: Orientation) => void
): void
```

移除方向监听器。

* 未传入 `callback` 时将停止所有方向监听并结束观察

---

## Proximity Listeners

### addProximityStateListener

```ts
function addProximityStateListener(
  callback: (state: boolean) => void
): void
```

监听接近传感器状态变化。

---

### removeProximityStateListener

```ts
function removeProximityStateListener(
  callback?: (state: boolean) => void
): void
```

移除接近传感器监听器。

---

## Network

### networkInterfaces

```ts
function networkInterfaces(): Record<string, NetworkInterface[]>
```

获取当前设备的网络接口信息。

返回值说明：

* Key：接口名称（如 `en0`、`lo0`）
* Value：该接口对应的地址信息数组

适用于网络诊断、本地 IP 获取、调试用途。
