`CustomKeyboard` 是 Scripting 提供的全局命名空间，用于开发 iOS 自定义键盘扩展。在 `keyboard.tsx` 脚本中使用该 API，可以渲染自定义键盘 UI，并访问当前输入状态、插入文本、控制光标、监听输入事件、调整高度，并在多个脚本之间导航切换。

## 脚本生命周期

收起键盘或切换到其他键盘时，当前脚本会结束，其创建的 Rime 会话也会关闭。再次打开键盘时会重新运行配置的默认脚本。需要跨次保留的状态请持久化，每次脚本启动时创建新的 Rime 会话。在键盘内切换脚本失败时，原脚本仍会保留运行。

键盘启动时使用本地已编译的键盘脚本。请先在 Scripting 中构建脚本，再到键盘使用；弹出键盘不会等待 iCloud 源文件下载。启动失败或超时时可点击**重试**；有其他本地键盘时，也可点击**选择键盘脚本**。启动超时无法打断持续阻塞界面线程的同步 JavaScript。

## 一、使用环境与前提

### 环境要求

* 必须在脚本项目中创建名为 **`keyboard.tsx`** 的文件；
* 所有 `CustomKeyboard` 方法 **仅可在键盘扩展环境中使用**；
* 在 **App 脚本、Intent (`intent.tsx`)、小组件 (`widget.tsx`) 中无法使用此 API**；
* 系统设置路径：

  ```
  设置 > 通用 > 键盘 > 键盘 > 添加新键盘 > 选择 Scripting
  ```

  添加后，进入 Scripting 键盘详情页，开启 **允许完全访问**，以启用网络请求、剪贴板访问等高级功能。

---

## 二、展示键盘 UI

### `present(node: VirtualNode): void`

用于展示自定义键盘界面。必须在 `keyboard.tsx` 中调用一次。

```tsx
function MyKeyboard() {
  return <Text>你好，世界</Text>
}

CustomKeyboard.present(<MyKeyboard />)
```

---

## 三、输入状态查询

| 属性名                | 类型                        | 说明          |
| ------------------ | ------------------------- | ----------- |
| `textBeforeCursor` | `string \| null` | 光标前的文本      |
| `textAfterCursor`  | `string \| null` | 光标后的文本      |
| `selectedText`     | `string \| null` | 当前选中的文本（如有） |
| `allText`          | `string`         | 当前输入的文本       |
| `hasText`          | `boolean`        | 输入框是否包含文本内容 |

---

## 四、输入特征（traits）

### `useTraits(): TextInputTraits`

获取当前输入框的系统特征（如键盘类型、返回键样式等）。值在 `textDidChange` 和 `selectionDidChange` 事件中自动更新。

### `traits: TextInputTraits`

为静态快照，不会自动更新。建议在组件中使用 `useTraits()`。

常见字段包括：

* `keyboardType`：如 `'default'`, `'emailAddress'`, `'numberPad'`
* `returnKeyType`：如 `'done'`, `'go'`, `'search'`
* `textContentType`：如 `'username'`, `'password'`, `'oneTimeCode'`
* `keyboardAppearance`：`'light'`, `'dark'` 等

---

## 五、文本操作

### `insertText(text: string): void`

在光标处插入文本。

### `deleteBackward(): void`

删除光标前的一个字符。

### `moveCursor(offset: number): void`

移动光标位置。负数为向左，正数为向右。

### `setMarkedText(text, location, length): void`

设置标记文本（用于拼音输入等组合输入）。

### `unmarkText(): void`

取消当前标记文本。

---

## 六、键盘行为控制

### `dismiss(): void`

关闭键盘。

### `nextKeyboard(): void`

切换至系统中的下一个键盘。

### `requestHeight(height: number): void`

请求调整键盘高度（单位为 pt）。推荐范围为 **216~360pt**，超出范围可能被系统忽略。

### `setHasDictationKey(value: boolean): void`

设置是否显示语音输入按钮（麦克风图标）。

### `setToolbarVisible(visible: boolean): void`

控制顶部工具栏的显示/隐藏。默认显示，适用于调试等场景。

---

## 七、导航控制

### `allScripts: KeyboardScriptInfo[]`

列出所有可以在自定义键盘扩展中运行的脚本。

```ts
const scripts = CustomKeyboard.allScripts
```

每一项包含：

| 属性              | 类型       | 说明               |
| ----------------- | ---------- | ------------------ |
| `name`            | `string`   | 脚本的稳定名称     |
| `localizedName`   | `string`   | 当前语言下的显示名 |
| `icon`            | `string`   | 脚本的 SF Symbol   |
| `color`           | `string`   | 脚本颜色名称       |

### `switchToScript(scriptName: string, queryParameters?: Record<string, string>): Promise<void>`

关闭当前键盘脚本，并按脚本名称运行另一个键盘脚本。
可选的 `queryParameters` 会作为目标脚本的 `Script.queryParameters` 暴露。

```ts
await CustomKeyboard.switchToScript("Rime Pinyin DEMO", {
  source: Script.name,
  mode: "symbols",
})
```

### `nextScript(queryParameters?: Record<string, string>): Promise<void>`

关闭当前键盘脚本，并运行下一个可用的键盘脚本。
可选的 `queryParameters` 会作为目标脚本的 `Script.queryParameters` 暴露。

```ts
await CustomKeyboard.nextScript({
  source: Script.name,
})
```

### `dismissToHome(): void`

关闭当前键盘脚本，返回 Scripting 键盘首页（脚本列表）。适用于用户在多个脚本之间自由切换的场景。

```ts
CustomKeyboard.dismissToHome()
```

---

## 八、用户反馈

### `playInputClick(): void`

播放标准键盘按键音，建议在模拟按键操作时调用，提升交互体验。

```ts
CustomKeyboard.playInputClick()
```

---

## 九、事件监听

### `addListener(event, callback): void`

注册事件监听器：

| 事件名                   | 回调参数                                | 说明     |
| --------------------- | ----------------------------------- | ------ |
| `textWillChange`      | `() => void`                        | 文本将要变更 |
| `textDidChange`       | `(traits: TextInputTraits) => void` | 文本已变更  |
| `selectionWillChange` | `() => void`                        | 光标将变更  |
| `selectionDidChange`  | `(traits: TextInputTraits) => void` | 光标已变更  |

### `removeListener(event, callback): void`

移除指定监听器。

### `removeAllListeners(event): void`

移除指定事件的所有监听器。

---

## 十、完整示例

```tsx
function MyKeyboard() {
  const traits = CustomKeyboard.useTraits()

  const insert = async (text: string) => {
    CustomKeyboard.playInputClick()
    CustomKeyboard.insertText(text)
  }

  return (
    <VStack spacing={12}>
      <Text>输入类型：{traits.keyboardType}</Text>
      <HStack spacing={10}>
        <Button title="你" action={() => insert("你")} />
        <Button title="好" action={() => insert("好")} />
        <Button title="← 删除" action={() => CustomKeyboard.deleteBackward()} />
        <Button title="返回首页" action={() => CustomKeyboard.dismissToHome()} />
      </HStack>
    </VStack>
  )
}

CustomKeyboard.present(<MyKeyboard />)
```

---

## 十一、开发建议

* **必须调用 `present()` 并且仅调用一次**；
* 合理设置键盘高度，避免 UI 被遮挡；
* 使用 `useTraits()` 获取输入上下文信息；
* 调用 `dismissToHome()` 可以让用户在多个键盘脚本之间切换；
* 通过 `playInputClick()` 提升按键交互体验；
* 删除文本前请先判断 `hasText` 是否为 true；
* 监听事件时注意避免重复注册和内存泄漏；
