# BackgroundKeeper

The main Scripting app provides this global in scripts running from `index`, `home_screen`, and `camera_control`. Request resources in the foreground and stop the request when the work finishes. The system can interrupt either resource or suspend or terminate the app. Check actual network responses separately.

## Modes

| Mode | Behavior |
| --- | --- |
| `"audio"` | Uses the shared background audio resource. This is the default for existing scripts. |
| `"location"` | Extends background location access for this script's running `Location` subscription. Start location updates and register a listener before calling. iOS controls permission and the location indicator. |
| `"audioAndLocation"` | Requests both resources. Both must be available for the call to succeed. |

## API

- `await BackgroundKeeper.keepAlive(mode?)` resolves to `true` when the requested mode is available. Operational failures resolve to `false`. Invalid arguments and script access failures reject. Repeat the same mode without adding another request. A failed switch preserves the prior request.
- `await BackgroundKeeper.getState()` returns the script's `requestedMode`, available `activeModes`, and each resource's `modeStates` with `status` and `lastFailure`. The original `status`, `isActive`, and `lastFailure` describe app-wide audio. The original `requested` reports whether this script holds audio.
- `await BackgroundKeeper.isActive` reads the app-wide audio state. It becomes false during audio interruption or when the player stops.
- `await BackgroundKeeper.stopKeepAlive()` releases this script's request. Exiting the script also releases it. Other scripts retain their requests.

## Example

```ts
async function recordLocationForFiveMinutes(onLocation: (location: { latitude: number; longitude: number }) => void) {
  Location.addLocationListener(onLocation)
  try {
    await Location.startUpdatingLocation()
    if (!await BackgroundKeeper.keepAlive("location")) {
      console.log((await BackgroundKeeper.getState()).modeStates.location)
      return
    }
    await new Promise<void>(resolve => setTimeout(resolve, 300_000))
  } finally {
    await BackgroundKeeper.stopKeepAlive()
    Location.removeLocationListener(onLocation)
    Location.stopUpdatingLocation()
  }
}
```

Use location access only for work that needs ongoing updates. If location authorization changes or a location stream stops, its background access ends. To recover from a resource interruption, inspect its state and retry when appropriate.
