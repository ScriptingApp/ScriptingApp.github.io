# BackgroundKeeper

Scripting 主 App 在 `index`、`home_screen` 和 `camera_control` 脚本中提供这个全局对象。请在前台申请资源，工作结束后释放。系统可能中断资源、挂起或终止 App。网络任务仍需检查实际响应。

## 模式

| 模式 | 行为 |
| --- | --- |
| `"audio"` | 使用共享的后台音频资源。已有脚本的默认模式。 |
| `"location"` | 为当前脚本的 `Location` 订阅提供后台位置访问。调用前先启动位置更新并添加监听回调。定位权限和系统指示由 iOS 管理。 |
| `"audioAndLocation"` | 同时申请两项资源。两项都可用时才返回成功。 |

## API

- `await BackgroundKeeper.keepAlive(mode?)` 在所选模式可用时返回 `true`。资源不可用时返回 `false`，参数错误或脚本访问失败会拒绝 Promise。重复申请相同模式不会累加请求。切换失败会保留原请求。
- `await BackgroundKeeper.getState()` 返回当前脚本的 `requestedMode`、可用的 `activeModes`，以及各资源的 `modeStates`（包含 `status` 和 `lastFailure`）。原有 `status`、`isActive` 和 `lastFailure` 描述 App 共享音频。原有 `requested` 表示本脚本是否持有音频请求。
- `await BackgroundKeeper.isActive` 读取 App 共享音频状态。音频中断或播放器停止时为 false。
- `await BackgroundKeeper.stopKeepAlive()` 释放本脚本的请求。脚本退出也会释放，其他脚本的请求仍然有效。

## 示例

```ts
async function recordLocationForFiveMinutes(onLocation: (location: { latitude: number; longitude: number }) => void) {
  Location.addLocationListener(onLocation)
  try {
    await Location.startUpdatingLocation()
    if (!await BackgroundKeeper.keepAlive("location")) {
      console.log((await BackgroundKeeper.getState()).modeStates.location)
      return
    }
    await new Promise<void>(resolve => setTimeout(resolve, 300_000))
  } finally {
    await BackgroundKeeper.stopKeepAlive()
    Location.removeLocationListener(onLocation)
    Location.stopUpdatingLocation()
  }
}
```

只为需要持续位置更新的任务使用定位。权限变化或定位流停止时，该定位请求的后台访问会结束。资源中断后可检查状态，在合适时机重试。
