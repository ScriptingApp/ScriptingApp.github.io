import { Button, GeometryReader, Navigation, NavigationStack, Rectangle, Script, ScrollView, Text, VStack, ZStack, useState } from "scripting"

const zh = Device.systemLanguageTag.startsWith("zh")
const copy = zh ? {
  title: "自定义 Alert", open: "打开详细说明", close: "关闭示例", heading: "请查看详细说明",
  intro: "自定义弹窗可以展示比系统 Alert 更多的内容。下面的内容可以滚动，底部按钮始终可用。",
  sections: ["一、确认操作范围：仅处理本次选择的项目。", "二、保留重要信息：操作前请检查需要保留的内容。", "三、查看结果：确认或取消后，结果会显示在原页面。", "四、无障碍：可以逐项阅读内容，并使用明确的按钮完成操作。"],
  cancel: "取消", confirm: "确认", idle: "尚未选择", accepted: "已确认", cancelled: "已取消",
} : {
  title: "Custom Alert", open: "Open detailed information", close: "Close demo", heading: "Review the details",
  intro: "A custom alert can show more content than a system alert. Scroll through the details; the action buttons remain available below.",
  sections: ["1. Check the scope: only the selected items are included.", "2. Keep important information: review anything you need to preserve before continuing.", "3. See the result: your choice appears on the original page after confirming or cancelling.", "4. Accessibility: read each section and use the labelled buttons to finish."],
  cancel: "Cancel", confirm: "Confirm", idle: "No selection yet", accepted: "Confirmed", cancelled: "Cancelled",
}

type Choice = "confirmed" | "cancelled"

function CustomAlertView() {
  const dismiss = Navigation.useDismiss()
  return <GeometryReader>
    {geometry => <ZStack frame={{ width: geometry.size.width, height: geometry.size.height }}>
      <Rectangle fill="rgba(0,0,0,0.45)" ignoresSafeArea accessibilityHidden />
      <VStack
        spacing={16}
        padding={20}
        frame={{ width: Math.max(1, Math.min(420, geometry.size.width - 40)) }}
        background="systemBackground"
        clipShape={{ type: "rect", cornerRadius: 20 }}
        accessibilityElement="contain"
        accessibilityAddTraits="isModal"
        accessibilityIdentifier="custom-alert"
      >
        <ScrollView frame={{ maxHeight: Math.max(1, Math.min(360, geometry.size.height * 0.55)) }}>
          <VStack alignment="leading" spacing={16}>
            <Text font="title2" accessibilityHeading="h1">{copy.heading}</Text>
            <Text>{copy.intro}</Text>
            {copy.sections.map(section => <Text key={section}>{section}</Text>)}
          </VStack>
        </ScrollView>
        <Button title={copy.confirm} action={() => dismiss("confirmed")} accessibilityIdentifier="custom-alert.confirm" />
        <Button title={copy.cancel} action={() => dismiss("cancelled")} accessibilityIdentifier="custom-alert.cancel" />
      </VStack>
    </ZStack>}
  </GeometryReader>
}

function Demo() {
  const dismiss = Navigation.useDismiss()
  const [result, setResult] = useState(copy.idle)
  const [presenting, setPresenting] = useState(false)
  async function showAlert() {
    setPresenting(true)
    try {
      const choice = await Navigation.present<Choice | undefined>({
        element: <CustomAlertView />,
        modalPresentationStyle: "overFullScreen",
        isModalInPresentation: true,
      })
      setResult(choice === "confirmed" ? copy.accepted : copy.cancelled)
    } finally {
      setPresenting(false)
    }
  }
  return <NavigationStack>
    <VStack navigationTitle={copy.title} spacing={20} padding>
      <Text accessibilityIdentifier="custom-alert.result">{result}</Text>
      <Button title={copy.open} action={() => { void showAlert().catch(console.error) }} disabled={presenting} accessibilityIdentifier="custom-alert.open" />
      <Button title={copy.close} action={() => dismiss()} />
    </VStack>
  </NavigationStack>
}

Navigation.present(<Demo />).catch(console.error).finally(() => Script.exit())
