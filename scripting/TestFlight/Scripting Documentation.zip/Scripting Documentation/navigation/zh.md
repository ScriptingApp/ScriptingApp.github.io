# Navigation

从 `scripting` 导入 `Navigation`，用于展示脚本页面、自定义弹窗，以及在页面关闭时返回结果。这些 API 需要能够展示前台界面的脚本环境。

## `Navigation.present<T = any>(options): Promise<T>`

接收视图本身或选项对象：

```tsx
import { Navigation, Text } from "scripting"

await Navigation.present(<Text>Hello</Text>)
```

| 选项 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| `element` | `VirtualNode` | 必填 | 要展示的根视图。 |
| `modalPresentationStyle` | `ModalPresentationStyle` | `"pageSheet"` | 页面呈现样式。 |
| `isModalInPresentation` | `boolean` | `false` | 禁止本次模态页面的交互式关闭；仍可显式调用 `useDismiss()` 关闭。 |
| `swipeBackBehavior` | `"disabled" \| "dismiss" \| "minimize"` | `"disabled"` | `fullScreen` 或 `overFullScreen` 页面从左边缘向右滑动后的操作。 |

`ModalPresentationStyle` 支持 `"automatic"`、`"currentContext"`、`"formSheet"`、`"fullScreen"`、`"overCurrentContext"`、`"overFullScreen"` 和 `"pageSheet"`。

Promise 等待本页真正关闭后完成。`useDismiss(result)` 提供返回结果；交互式关闭返回 `undefined`，需要时应将其包含在 `T` 中。关闭页面本身不会结束脚本。最小化会保留页面，Promise 继续等待到页面关闭。

### 交互式关闭限制

`isModalInPresentation: true` 会禁止系统交互式关闭，例如下拉关闭 sheet，也会禁止模态页面的边缘返回操作及对应的 VoiceOver 退出操作。请提供有明确标签的关闭、取消或确认按钮。

这是本次呈现的固定选项。需要随页面状态变化时，可以使用现有的 `interactiveDismissDisabled` modifier。任意一项限制都可以阻止关闭：参数为 `false` 不会解除值为 `true` 的 modifier；modifier 改为 `false` 也不能解除固定参数的 `true`。

此参数不会阻止显式调用 `useDismiss(result)`、`Script.exit()`，也不会阻止脚本自定义的遮罩点击事件调用 `useDismiss()`。

### 全屏边缘返回

- `"dismiss"` 关闭本页，Promise 返回 `undefined`。
- `"minimize"` 隐藏并保留脚本。仅脚本第一个呈现页面且 `Script.supportsMinimization()` 为 true 时可用，否则禁用该手势。
- 内层导航栈已进入子页面时优先栈内返回；上方还有其他模态页面时需先关闭上层。取消滑动不执行操作。
- 其他呈现样式忽略 `swipeBackBehavior`。`Script.enableMinimize()` 单独控制系统 sheet 的下拉行为。
- 页面根层的 VoiceOver 退出操作使用相同边缘返回行为并遵守相同限制；同时应始终提供可访问的按钮。

参见[全屏手势完整示例](../views/present_views/present_a_simple_view/zh.md)。

## `Navigation.useDismiss()`

在页面组件内调用此 hook，取得 `(result?: any) => void`，再从按钮或事件处理器关闭当前呈现并返回结果。每个嵌套页面有自己的关闭上下文。在没有关闭上下文的嵌入式宿主中，例如 Home UI 根页面，返回的函数不执行操作。

```tsx
import { Button, Navigation, Text, VStack } from "scripting"

function Choice() {
  const dismiss = Navigation.useDismiss()
  return <VStack>
    <Text>是否继续？</Text>
    <Button title="确认" action={() => dismiss(true)} />
    <Button title="取消" action={() => dismiss(false)} />
  </VStack>
}

const confirmed = await Navigation.present<boolean | undefined>({ element: <Choice /> })
console.log(confirmed)
```

## 展示更多内容的自定义 Alert

使用 `overFullScreen` 呈现带半透明遮罩的自定义弹窗。它保留下方页面，由脚本绘制遮罩、卡片、内容和按钮。`NavigationStack` 是可选项，它本身可能带来不透明背景。

```tsx
import { Button, Navigation, Rectangle, ScrollView, Text, VStack, ZStack } from "scripting"

function CustomAlertView() {
  const dismiss = Navigation.useDismiss()
  return <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
    <Rectangle fill="rgba(0,0,0,0.45)" ignoresSafeArea accessibilityHidden />
    <VStack padding={20} background="systemBackground" accessibilityElement="contain" accessibilityAddTraits="isModal">
      <ScrollView frame={{ maxHeight: 280 }}>
        <Text accessibilityHeading="h1">Review the details</Text>
        <Text>Put your longer message and custom content here.</Text>
      </ScrollView>
      <Button title="Confirm" action={() => dismiss("confirmed")} />
      <Button title="Cancel" action={() => dismiss("cancelled")} />
    </VStack>
  </ZStack>
}

const choice = await Navigation.present<"confirmed" | "cancelled" | undefined>({
  element: <CustomAlertView />,
  modalPresentationStyle: "overFullScreen",
  isModalInPresentation: true,
})
```

预览提供完整可运行的 [index.tsx](index.tsx)：从宿主页面打开弹窗，滚动查看较多内容，确认或取消后在宿主页面看到返回结果。点击遮罩不会关闭；卡片根据可用宽度布局，按钮放在滚动区域之外。

使用原生按钮、清晰标签，并用 `accessibilityHeading` 标记标题。弹窗容器设置 `accessibilityElement="contain"` 与 `accessibilityAddTraits="isModal"`，装饰性遮罩设置 `accessibilityHidden`，保留各个按钮可访问。`accessibilityIdentifier` 用于稳定的 UI 测试标识；朗读标签使用可见文字或 `accessibilityLabel`。这些 modifiers 均支持 JSX 属性和链式写法。参见[无障碍修饰符](../view_modifiers/accessibility/zh.md)。

`isModal` 描述无障碍导航语义，`isModalInPresentation` 控制交互式关闭。请通过 VoiceOver 检查焦点进入弹窗、阅读顺序、所有按钮可用及关闭后焦点返回，并检查大字体和横屏布局。

## 环境与兼容性

- iPad 启用独立脚本窗口时，第一次 `present` 打开脚本窗口。模态样式和关闭选项不会让窗口覆盖主 App，也不会禁止系统关闭窗口。可以像本 DEMO 一样，在窗口中再次调用 `present` 打开模态弹窗。
- 静态 Widget、Intent 快照不属于可交互模态呈现场景；`useDismiss()` 不会创建原本不存在的关闭上下文。
- `isModalInPresentation` 需要包含本次 API 更新的 Scripting 构建；旧构建不会实施此选项的关闭限制，请勿在旧安装版本中依赖该限制。
