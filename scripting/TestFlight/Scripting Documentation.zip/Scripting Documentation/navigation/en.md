# Navigation

Import `Navigation` from `scripting` to present script pages, show custom alerts, and return a result when a page closes. These APIs require a script environment that can present foreground UI.

## `Navigation.present<T = any>(options): Promise<T>`

Accepts either a view directly or an options object:

```tsx
import { Navigation, Text } from "scripting"

await Navigation.present(<Text>Hello</Text>)
```

| Option | Type | Default | Description |
| --- | --- | --- | --- |
| `element` | `VirtualNode` | Required | The root view to present. |
| `modalPresentationStyle` | `ModalPresentationStyle` | `"pageSheet"` | How the page is presented. |
| `isModalInPresentation` | `boolean` | `false` | Prevents interactive dismissal of this modal page. Explicit `useDismiss()` calls still work. |
| `swipeBackBehavior` | `"disabled" \| "dismiss" \| "minimize"` | `"disabled"` | Action for a left-edge rightward swipe on `fullScreen` or `overFullScreen` pages. |

`ModalPresentationStyle` accepts `"automatic"`, `"currentContext"`, `"formSheet"`, `"fullScreen"`, `"overCurrentContext"`, `"overFullScreen"`, and `"pageSheet"`.

The promise waits until this page actually closes. `useDismiss(result)` supplies its result. Interactive dismissal returns `undefined`; include that possibility in `T` when relevant. Closing a page does not itself end the script. Minimizing keeps the page and its promise alive until the page closes.

### Interactive dismissal

`isModalInPresentation: true` prevents system interactive dismissal, such as pulling down a sheet. It also blocks the modal edge-back action and its VoiceOver escape action. Provide a labelled Close, Cancel, or Confirm button.

This is a fixed option for this presentation. For a restriction that changes with page state, use the existing `interactiveDismissDisabled` modifier. Either restriction can block dismissal: passing `false` does not override a modifier set to `true`, and changing the modifier to `false` cannot remove a fixed `true` option.

The option does not block explicit `useDismiss(result)`, `Script.exit()`, or a custom backdrop action that calls `useDismiss()`.

### Full-screen edge-back

- `"dismiss"` closes this page and resolves the promise with `undefined`.
- `"minimize"` hides and retains the script. It is available only on the first presented page when `Script.supportsMinimization()` is true; otherwise the gesture is disabled.
- A pushed inner navigation stack goes back first; an additional modal above must close first. A cancelled swipe performs no action.
- Other presentation styles ignore `swipeBackBehavior`. `Script.enableMinimize()` separately controls the system sheet swipe.
- At the page root, VoiceOver escape uses the configured edge-back action and respects the same restrictions. Always provide an accessible button as well.

See [the full-screen gesture examples](../views/present_views/present_a_simple_view/en.md).

## `Navigation.useDismiss()`

Call this hook inside the page component to obtain `(result?: any) => void`. Use it from a button or event handler to close the current presentation and return a result. Each nested page gets its own dismissal context. In an embedded host without a dismissal context, such as a Home UI root, the returned function has no effect.

```tsx
import { Button, Navigation, Text, VStack } from "scripting"

function Choice() {
  const dismiss = Navigation.useDismiss()
  return <VStack>
    <Text>Continue?</Text>
    <Button title="Confirm" action={() => dismiss(true)} />
    <Button title="Cancel" action={() => dismiss(false)} />
  </VStack>
}

const confirmed = await Navigation.present<boolean | undefined>({ element: <Choice /> })
console.log(confirmed)
```

## Custom alerts with more content

Use `overFullScreen` for a custom alert with a translucent backdrop. The presentation preserves the page beneath; draw the backdrop, card, content and buttons in your view. A `NavigationStack` is optional and can introduce its own opaque background.

```tsx
import { Button, Navigation, Rectangle, ScrollView, Text, VStack, ZStack } from "scripting"

function CustomAlertView() {
  const dismiss = Navigation.useDismiss()
  return <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
    <Rectangle fill="rgba(0,0,0,0.45)" ignoresSafeArea accessibilityHidden />
    <VStack padding={20} background="systemBackground" accessibilityElement="contain" accessibilityAddTraits="isModal">
      <ScrollView frame={{ maxHeight: 280 }}>
        <Text accessibilityHeading="h1">Review the details</Text>
        <Text>Put your longer message and custom content here.</Text>
      </ScrollView>
      <Button title="Confirm" action={() => dismiss("confirmed")} />
      <Button title="Cancel" action={() => dismiss("cancelled")} />
    </VStack>
  </ZStack>
}

const choice = await Navigation.present<"confirmed" | "cancelled" | undefined>({
  element: <CustomAlertView />,
  modalPresentationStyle: "overFullScreen",
  isModalInPresentation: true,
})
```

The preview provides the complete runnable [index.tsx](index.tsx): open an alert from a host page, scroll through longer content, confirm or cancel, and see the returned result on the host page. The backdrop does not dismiss on tap. The card adapts to the available width and keeps the buttons outside the scrolling content.

Use native buttons, meaningful labels and `accessibilityHeading` for the title. Group the card with `accessibilityElement="contain"` and `accessibilityAddTraits="isModal"` while hiding the decorative backdrop with `accessibilityHidden`. Keep individual buttons accessible. `accessibilityIdentifier` provides stable UI test identifiers; use visible text or `accessibilityLabel` for spoken labels. Both JSX props and fluent modifiers are available. See [accessibility modifiers](../view_modifiers/accessibility/en.md).

`isModal` describes accessibility navigation; `isModalInPresentation` controls interactive dismissal. Check focus entering the alert, reading order, access to all buttons, and focus returning after closure with VoiceOver. Check large text and landscape layouts too.

## Environments and compatibility

- With independent script windows enabled on iPad, the first `present` opens a script window. Modal style and dismissal options do not turn that window into an overlay or prevent system window closure. A later `present` inside that window can show a modal alert, as in this demo.
- Static widget and Intent snapshots are not interactive modal presentations. `useDismiss()` does not create a missing presentation context.
- `isModalInPresentation` requires a Scripting build containing this API update; older builds do not enforce this option. Do not rely on it in older installations.
