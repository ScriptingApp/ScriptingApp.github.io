import { Button, Navigation, NavigationStack, Script, ScrollView, Text, TextField, useEffect, useMemo, useRef, useState, VideoPlaybackPlayer, VStack } from "scripting"

function Example() {
  const dismiss = Navigation.useDismiss()
  const player = useMemo(() => new VideoPlaybackController(), [])
  const [videoURL, setVideoURL] = useState("")
  const [userAgent, setUserAgent] = useState("")
  const [connections, setConnections] = useState("1")
  const [forwardBuffer, setForwardBuffer] = useState("")
  const [diskMiB, setDiskMiB] = useState("")
  const [cacheID, setCacheID] = useState("")
  const [cacheMiB, setCacheMiB] = useState("256")
  const playingCacheID = useRef<string | null>(null)
  const [embyAuthorization, setEmbyAuthorization] = useState("")
  const [embyToken, setEmbyToken] = useState("")
  const [message, setMessage] = useState("Enter a video URL or choose a local media file.")
  const alive = useRef(true)
  const report = (value: string) => { if(alive.current) setMessage(value) }
  const [readDetail, setReadDetail] = useState("")
  useEffect(() => player.on("error", ({ readError }) => {
    if (!alive.current || !readError) return
    setReadDetail([readError.stage, `FFmpeg ${readError.ffmpegCode}`,
      readError.httpStatus === undefined ? undefined : `HTTP ${readError.httpStatus}`,
      readError.byteOffset === undefined ? undefined : `byte ${readError.byteOffset}`,
      readError.line].filter(Boolean).join(" · "))
  }), [player])
  const [busy, setBusy] = useState(false)
  function savePosition() {
    const id = playingCacheID.current
    if (id && Number.isFinite(player.position)) Storage.set(`video-playback-position.${id}`, player.position)
  }
  useEffect(() => () => { alive.current=false; savePosition(); void player.dispose() }, [player])
  async function openMedia(url?: string, options?: VideoPlaybackOpenOptions, id?: string) {
    setBusy(true)
    try {
      let source = url
      if (source === undefined) {
        const files = await DocumentPicker.pickFiles({ types: ["public.data"], allowsMultipleSelection: false })
        source = files[0]
      }
      if (!source || !alive.current) return
      setReadDetail("")
      report("Opening media…")
      savePosition()
      playingCacheID.current = null
      await SharedAudioSession.setCategory("playback", ["mixWithOthers"])
      await SharedAudioSession.setActive(true)
      const startTime = id ? (Storage.get<number>(`video-playback-position.${id}`) ?? 0) : 0
      const info = await player.open(source, { ...options, startTime })
      playingCacheID.current = id ?? null
      report(`Backend: ${info.backend}`)
      await player.play()
    } catch (error) { report(String(error)) }
    finally { if(alive.current) setBusy(false) }
  }
  async function pasteRequest() {
    setBusy(true)
    try {
      const request = (await Pasteboard.getString())?.trim() ?? ""
      if (!alive.current) return
      const target = /^GET[ \t]+(\S+)[ \t]+HTTP\/\d+(?:\.\d+)?[ \t]*\r?$/im.exec(request)?.[1]
      const host = /^Host:[ \t]*([^\s/?#@]+)[ \t]*\r?$/im.exec(request)?.[1]
      const agent = /^User-Agent:[ \t]*([^\r\n]+)$/im.exec(request)?.[1].trim()
      const authorization = /^X-Emby-Authorization:[ \t]*([^\r\n]+)$/im.exec(request)?.[1].trim()
      const token = /^X-Emby-Token:[ \t]*([^\r\n]+)$/im.exec(request)?.[1].trim()
      const source = target?.startsWith("/") && host
        ? `${host.endsWith(":80") ? "http" : "https"}://${host}${target}`
        : target
      if (!source || !/^https?:\/\/[^/?#\s]+/i.test(source)) {
        report("Copy a GET request with a full video URL or a Host header.")
        return
      }
      setVideoURL(source)
      setUserAgent(agent ?? "")
      setEmbyAuthorization(authorization ?? "")
      setEmbyToken(token ?? "")
      report("Request imported. Review the fields, then tap Play URL.")
    } catch (error) { report(String(error)) }
    finally { if (alive.current) setBusy(false) }
  }
  async function playURL() {
    const source = videoURL.trim()
    if (!/^https?:\/\/[^/?#\s]+/i.test(source)) {
      report("Enter an HTTP or HTTPS video URL.")
      return
    }
    const headers: Record<string, string> = {}
    for (const [name, value] of [
      ["User-Agent", userAgent],
      ["X-Emby-Authorization", embyAuthorization],
      ["X-Emby-Token", embyToken],
    ]) {
      const trimmed = value.trim()
      if (trimmed) headers[name] = trimmed
    }
    const count = Number(connections.trim())
    if (count !== 1 && count !== 2 && count !== 3 && count !== 4) {
      report("Enter 1 to 4 read connections.")
      return
    }
    const forwardBufferDuration = Number(forwardBuffer.trim())
    if (!Number.isFinite(forwardBufferDuration) || forwardBufferDuration < 0 || forwardBufferDuration > 300) {
      report("Forward buffer must be between 0 and 300 seconds.")
      return
    }
    const limit = diskMiB.trim() ? Number(diskMiB) : undefined
    if (limit !== undefined && (!Number.isInteger(limit) || limit < 64 || limit > 4096)) {
      report("Enter a disk limit from 64 to 4096 MiB.")
      return
    }
    const id = cacheID.trim()
    const maxBytes = Number(cacheMiB) * 1024 * 1024
    if (id && (!/^[a-zA-Z0-9_-]{1,64}$/.test(id) || !Number.isSafeInteger(maxBytes) || maxBytes <= 0)) {
      report("Use a cache ID of up to 64 letters, digits, hyphens or underscores and a positive MiB limit.")
      return
    }
    let resumeCache: VideoPlaybackResumeCacheOptions | undefined
    if (id) {
      const directory = `${FileManager.documentsDirectory}/VideoPlaybackResumeDemo/${id}`
      setBusy(true)
      try {
        if (!(await FileManager.exists(directory))) await FileManager.createDirectory(directory, true)
        if (!alive.current) return
        resumeCache = { directory, maxBytes }
      } catch (error) { report(String(error)); return }
      finally { if(alive.current) setBusy(false) }
    }
    return openMedia(source, {
      ...(limit === undefined ? {} : { maxForwardBufferBytes: limit * 1024 * 1024 }),
      ...(Object.keys(headers).length ? { headers } : {}),
      ...(forwardBufferDuration > 0 ? { forwardBufferDuration } : {}),
      maxReadConnections: count,
      ...(resumeCache ? { resumeCache } : {}),
    }, id || undefined)
  }
  async function subtitles() {
    try {
      const files = await DocumentPicker.pickFiles({ types: ["public.data"], allowsMultipleSelection: false })
      if (files.length && alive.current) await player.loadSubtitleFile(files[0])
    } catch (error) { report(String(error)) }
  }
  return <NavigationStack><ScrollView><VStack spacing={12} padding navigationTitle="Video Playback">
    <VideoPlaybackPlayer controller={player} title="Video Playback" frame={{height:260}} onError={error=>report(String(error))} />
    <Text>{message}</Text>
    {readDetail ? <Text>{readDetail}</Text> : null}
    <TextField
      title="Video URL"
      prompt="https://example.com/video.mp4"
      value={videoURL}
      onChanged={setVideoURL}
      keyboardType="URL"
      textInputAutocapitalization="never"
      autocorrectionDisabled
      disabled={busy}
    />
    <TextField title="Maximum read connections" value={connections} onChanged={setConnections} keyboardType="numberPad" disabled={busy} />
    <TextField
      title="Forward buffer (seconds, optional)"
      prompt="Automatic, or use disk limit only"
      value={forwardBuffer}
      onChanged={setForwardBuffer}
      keyboardType="decimalPad"
      disabled={busy}
    />
    <TextField title="Maximum disk buffer (MiB)" prompt="512" value={diskMiB} onChanged={setDiskMiB} keyboardType="numberPad" disabled={busy} />
    <TextField title="Resume cache ID (optional)" prompt="Use one ID per media source" value={cacheID} onChanged={setCacheID} textInputAutocapitalization="never" autocorrectionDisabled disabled={busy} />
    <TextField title="Resume cache limit (MiB)" value={cacheMiB} onChanged={setCacheMiB} keyboardType="numberPad" disabled={busy || !cacheID.trim()} />
    <TextField
      title="User-Agent"
      prompt="Optional"
      value={userAgent}
      onChanged={setUserAgent}
      textInputAutocapitalization="never"
      autocorrectionDisabled
      disabled={busy}
    />
    <TextField
      title="X-Emby-Authorization"
      prompt="Optional"
      value={embyAuthorization}
      onChanged={setEmbyAuthorization}
      textInputAutocapitalization="never"
      autocorrectionDisabled
      disabled={busy}
    />
    <TextField
      title="X-Emby-Token"
      prompt="Optional"
      value={embyToken}
      onChanged={setEmbyToken}
      textInputAutocapitalization="never"
      autocorrectionDisabled
      disabled={busy}
    />
    <Button title="Paste HTTP Request" disabled={busy} action={pasteRequest} />
    <Button title="Play URL" disabled={busy || !videoURL.trim()} action={playURL} />
    <Button title="Stop and save position" disabled={busy || !playingCacheID.current} action={async () => {
      setBusy(true)
      try {
        savePosition()
        playingCacheID.current = null
        await player.stop()
        report("Position saved. Play URL again with the same cache ID to resume.")
      } catch (error) { report(String(error)) }
      finally { if (alive.current) setBusy(false) }
    }} />
    <Button title="Check resume cache" disabled={busy || !playingCacheID.current} action={async () => {
      try {
        const status = await player.getResumeCacheStatus()
        if (status) report(`Resume cache: ${status.state} · ${status.hitBytes} bytes from disk · ${status.networkBytes} bytes from network`)
      } catch (error) { report(String(error)) }
    }} />
    <Button title="Clear this demo's resume cache" disabled={busy || !/^[a-zA-Z0-9_-]{1,64}$/.test(cacheID.trim())} action={async () => {
      const id = cacheID.trim()
      const directory = `${FileManager.documentsDirectory}/VideoPlaybackResumeDemo/${id}`
      setBusy(true)
      try {
        savePosition()
        playingCacheID.current = null
        await player.stop()
        if (await FileManager.exists(directory)) await FileManager.remove(directory)
        report("Download cache cleared. The saved position is still available.")
      } catch (error) { report(String(error)) }
      finally { if (alive.current) setBusy(false) }
    }} />
    <Button title="Choose media" disabled={busy} action={() => openMedia()} />
    <Button title="Load subtitles" disabled={busy} action={subtitles} />
    <Button title="Add danmaku" action={async()=>{
      try { await player.injectDanmaku([{time:player.position+1,text:"Hello",mode:"scroll"}]) }
      catch(error) { report(String(error)) }
    }} />
    <Button title="Done" action={async()=>{savePosition();playingCacheID.current=null;await player.dispose();dismiss()}} />
  </VStack></ScrollView></NavigationStack>
}
async function run() {
  await Navigation.present(<Example />)
  Script.exit()
}
run()
