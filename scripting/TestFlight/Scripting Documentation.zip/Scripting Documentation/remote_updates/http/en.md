# Remote updates HTTP API

Base URL: `https://push.scripting.fun/v1/remote-updates`. Send `Authorization: Bearer <credential>` and `Content-Type: application/json`. Dates use UTC ISO 8601; JSON fields use snake_case.

## Credentials

The master key manages targets and sender keys. It cannot start, update or reload targets directly; no-new-state end cleanup is allowed. Legacy notification child keys cannot use these endpoints.

Create a sender with `POST /sender-keys`: `targets` (explicit IDs), `actions` (from the table below), optional `created_from` (start target IDs), and `idempotency_key`. The response contains `id`, `credential`, `expires_at`. Save the credential securely. `created_from` grants access only to activities created by that same sender. `GET /sender-keys` lists metadata; `DELETE /sender-keys/:id` revokes a key. These management operations use the master key.

You can also create and copy a scoped sender key from a target's **Create Sender Key** action in Remote Updates. Never put the master key in widget code or business state.

## Sending

| Method and path | Required action | Body |
|---|---|---|
| GET `/widget-targets/:id/state` | `widgets:read-state` | — |
| PUT `/widget-targets/:id/state` | `widgets:write-state` | `state`, `expected_revision`, `idempotency_key`; optional `source_version`, `expires_at` |
| POST `/widget-targets/:id/reload` | `widgets:reload` | `idempotency_key`; optional `expires_at` |
| POST `/start-targets/:id/start` | `activities:start` | `template_version`, `state`, `alert: {title,body}`, `idempotency_key`; optional `business_key`, `business_generation`, `priority`, `stale_at`, `relevance_score`, `expires_at` |
| GET `/activities/:id/state` | `activities:read-state` | — |
| POST `/activities/:id/update` | `activities:update` | `state`, `expected_revision`, `idempotency_key`; optional `source_version`, `stale_at`, `relevance_score`, `priority`, `alert`, `expires_at` |
| POST `/activities/:id/end` | `activities:end` | `idempotency_key`; optional `state`, `expected_revision`, `dismiss_at`, `expires_at` |

New final state requires `expected_revision`. Omit state to end with the last committed state. `priority` is `normal` or `high`; `relevance_score` is 0–1. Transport expiry defaults to five minutes and may be at most 24 hours in the future.

## Responses and queries

Successful JSON responses are `{ok:true,data,timestamp}`. Sending returns HTTP 202 with `{target_id,state_revision,state_committed,launch_request_id?,operation}`. A snapshot contains `target_id`, `has_state`, `state`, `revision`. GET state supports `ETag` / `If-None-Match` and may return HTTP 304 without a body.

- GET `/operations/:id`: operation status, pending reason, error and transport ID when available.
- GET `/widget-targets`, `/activities`, `/start-targets`: paginated metadata (`items`, `next_cursor`); use `cursor` for the next page. Optional filters: `installation_id`, `script_binding_id`; activities also accept `business_key`, `business_generation`, `lifecycle`.
- GET `/<collection>/:id`: target metadata. Master keys may query management metadata; sender results are restricted to their scope.
- PUT `/<collection>/:id/settings`: master-managed `expected_revision`, optional `paused`, `alias` (up to 128 UTF-16 units, null clears). DELETE `/<collection>/:id` revokes the target.
- POST `/widget-targets/batch` or `/activities/batch`: `{items:[{target_id,action,...}]}`, 1–50 items. Widget actions: `update` / `reload`; activity actions: `update` / `end`. Inspect each item's `ok`, `http_status` and receipt/error; partial success is possible.
- GET `/capabilities`: protocol features and limits; this does not prove device readiness.

Settings use `registration_revision` from target metadata as `expected_revision`; state writes use the snapshot’s `revision`. Sender creation accepts at most 100 target IDs and 100 `created_from` IDs.

## Example: start, update and end

Prepare the receiver using the [Live Activity guide](scripting://doc?title=Live%20Activity%20Remote%20Updates) and create a sender authorized for the start target and its created activities. Persist each request before sending. After a timeout, resend that exact request instead of rebuilding it from newer state.

<!-- example: server.mjs -->
```js
// Run on your server with Node.js 18+, not inside widget.tsx/live_activity.tsx.
// Supply a scoped sender key created for this start target and its created instances.
const base = process.env.SCRIPTING_PUSH_BASE_URL
const senderKey = process.env.SCRIPTING_REMOTE_SENDER_KEY
if (!base || !senderKey) throw new Error("Configure the server URL and scoped sender key")

async function remote(path, method = "GET", body) {
  const response = await fetch(new URL(`/v1/remote-updates${path}`, base), {
    method,
    headers: { Authorization: `Bearer ${senderKey}`, "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const result = await response.json()
  if (!response.ok || !result.ok) throw new Error(result.code || "REMOTE_UPDATE_FAILED")
  return result.data
}

function request(path, method, body) { return { path, method, body } }

export async function sendRemoteRequest(savedRequest) {
  return remote(savedRequest.path, savedRequest.method, savedRequest.body)
}

export function startDeliveryRequest(startTargetId, templateVersion, orderId) {
  return request(`/start-targets/${encodeURIComponent(startTargetId)}/start`, "POST", {
    template_version: templateVersion,
    business_key: `delivery:${orderId}`,
    business_generation: "1",
    state: { message: "Preparing" },
    alert: { title: "Delivery", body: "Tracking your delivery" },
    idempotency_key: `delivery:${orderId}:start:1`,
  })
}

export async function updateDeliveryRequest(targetId, eventId, message) {
  const snapshot = await remote(`/activities/${encodeURIComponent(targetId)}/state`)
  return request(`/activities/${encodeURIComponent(targetId)}/update`, "POST", {
    state: { message },
    expected_revision: snapshot.revision,
    idempotency_key: `delivery:${eventId}`,
  })
}

export function endDeliveryRequest(targetId, orderId) {
  return request(`/activities/${encodeURIComponent(targetId)}/end`, "POST", {
    idempotency_key: `delivery:${orderId}:end:1`,
  })
}
// Build a request, persist it in your business database, then call sendRemoteRequest.
// After a timeout, call sendRemoteRequest with that same persisted request.
// Do not rebuild it from a newer snapshot when retrying an uncertain request.
// After VERSION_CONFLICT, read again and decide whether the business event is still current.
```

## Limits and failures

JSON body: 64 KiB; widget state: 16 KiB; complete escaped Activity APNs payload: 4 KiB. State replaces the full JSON value. Notifications and updates share the [daily push quota](scripting://doc?title=Remote%20Updates%20Overview).

Errors are `{ok:false,code,error?,details?,request_id?,timestamp?}`. HTTP 400 indicates invalid arguments/schema/payload; 401 invalid or expired credentials; 403 denied scope or unavailable account access; 404 invisible resources; 409 stale revisions, conflicting idempotency or pending tokens; 410 revoked resources; 429 exhausted quota/rate limit. Inspect `code`: `VERSION_CONFLICT` needs a fresh read and business decision, `IDEMPOTENCY_CONFLICT` needs corrected request persistence, `TOKEN_PENDING` needs registration, and `PUSH_LIMIT_EXCEEDED` needs available daily quota. These are not reasons to loop with a new key.

Poll the operation after acceptance. An `unknown` start must be reconciled using the same launch; do not start another instance. Retries retain the same idempotency key and payload. A new business lifecycle deliberately uses a new generation.
