# 远程更新 HTTP API

基础地址：`https://push.scripting.fun/v1/remote-updates`。请求携带 `Authorization: Bearer <credential>` 和 `Content-Type: application/json`。日期采用 UTC ISO 8601，JSON 字段采用 snake_case。

## 凭据

主密钥管理目标和发送密钥，不能直接启动、更新或刷新目标；允许不带新状态的结束清理。旧普通通知子密钥不能调用这些接口。

通过主密钥调用 `POST /sender-keys` 创建发送密钥：传入 `targets`（明确的目标 ID）、`actions`（下表动作）、可选 `created_from`（启动目标 ID）和 `idempotency_key`。响应包含 `id`、`credential`、`expires_at`，请安全保存凭据。`created_from` 只覆盖该发送密钥自己创建的活动。主密钥可通过 `GET /sender-keys` 查看元数据，通过 `DELETE /sender-keys/:id` 撤销密钥。

也可在远程更新页面对目标执行“创建发送密钥”并复制。不要将主密钥放入小组件代码或业务状态。

## 发送接口

| 方法和路径 | 所需动作 | 请求体 |
|---|---|---|
| GET `/widget-targets/:id/state` | `widgets:read-state` | — |
| PUT `/widget-targets/:id/state` | `widgets:write-state` | `state`、`expected_revision`、`idempotency_key`；可选 `source_version`、`expires_at` |
| POST `/widget-targets/:id/reload` | `widgets:reload` | `idempotency_key`；可选 `expires_at` |
| POST `/start-targets/:id/start` | `activities:start` | `template_version`、`state`、`alert: {title,body}`、`idempotency_key`；可选 `business_key`、`business_generation`、`priority`、`stale_at`、`relevance_score`、`expires_at` |
| GET `/activities/:id/state` | `activities:read-state` | — |
| POST `/activities/:id/update` | `activities:update` | `state`、`expected_revision`、`idempotency_key`；可选 `source_version`、`stale_at`、`relevance_score`、`priority`、`alert`、`expires_at` |
| POST `/activities/:id/end` | `activities:end` | `idempotency_key`；可选 `state`、`expected_revision`、`dismiss_at`、`expires_at` |

提供新结束状态时必须带 `expected_revision`；省略状态表示用最后已提交状态结束。`priority` 为 `normal` 或 `high`，`relevance_score` 为 0–1。投递期限默认五分钟，最长为未来 24 小时。

## 响应与查询

成功 JSON 响应为 `{ok:true,data,timestamp}`。发送返回 HTTP 202，data 为 `{target_id,state_revision,state_committed,launch_request_id?,operation}`。快照包含 `target_id`、`has_state`、`state`、`revision`。GET state 支持 `ETag` / `If-None-Match`，可能返回无响应体的 HTTP 304。

- GET `/operations/:id`：查询操作状态、等待原因、错误和可用的传输 ID。
- GET `/widget-targets`、`/activities`、`/start-targets`：分页元数据（`items`、`next_cursor`），用 `cursor` 请求下一页。可选筛选 `installation_id`、`script_binding_id`；活动另支持 `business_key`、`business_generation`、`lifecycle`。
- GET `/<collection>/:id`：目标元数据。主密钥可查询管理元数据，发送密钥只可读取其权限范围。
- PUT `/<collection>/:id/settings`：主密钥管理，传 `expected_revision` 和可选 `paused`、`alias`（最多 128 个 UTF-16 单元，null 清空）。DELETE `/<collection>/:id` 撤销目标。
- POST `/widget-targets/batch` 或 `/activities/batch`：`{items:[{target_id,action,...}]}`，1–50 项。小组件动作为 `update` / `reload`，活动为 `update` / `end`。逐项检查 `ok`、`http_status` 和回执或错误，允许部分成功。
- GET `/capabilities`：查询协议功能和限制，不代表设备已经就绪。

设置接口使用目标元数据的 `registration_revision` 作为 `expected_revision`；状态写入使用快照的 `revision`。创建发送密钥最多接收 100 个目标 ID 和 100 个 `created_from` ID。

## 示例：启动、更新、结束

先按 [Live Activity 文档](scripting://doc?title=Live%20Activity%20Remote%20Updates) 准备接收端，再创建覆盖启动目标及其新活动的发送密钥。每个请求在发送前持久保存；超时后重发同一请求，不要从新快照重新构造。

<!-- example: server.mjs -->
```js
// Run on your server with Node.js 18+, not inside widget.tsx/live_activity.tsx.
// Supply a scoped sender key created for this start target and its created instances.
const base = process.env.SCRIPTING_PUSH_BASE_URL
const senderKey = process.env.SCRIPTING_REMOTE_SENDER_KEY
if (!base || !senderKey) throw new Error("Configure the server URL and scoped sender key")

async function remote(path, method = "GET", body) {
  const response = await fetch(new URL(`/v1/remote-updates${path}`, base), {
    method,
    headers: { Authorization: `Bearer ${senderKey}`, "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const result = await response.json()
  if (!response.ok || !result.ok) throw new Error(result.code || "REMOTE_UPDATE_FAILED")
  return result.data
}

function request(path, method, body) { return { path, method, body } }

export async function sendRemoteRequest(savedRequest) {
  return remote(savedRequest.path, savedRequest.method, savedRequest.body)
}

export function startDeliveryRequest(startTargetId, templateVersion, orderId) {
  return request(`/start-targets/${encodeURIComponent(startTargetId)}/start`, "POST", {
    template_version: templateVersion,
    business_key: `delivery:${orderId}`,
    business_generation: "1",
    state: { message: "Preparing" },
    alert: { title: "Delivery", body: "Tracking your delivery" },
    idempotency_key: `delivery:${orderId}:start:1`,
  })
}

export async function updateDeliveryRequest(targetId, eventId, message) {
  const snapshot = await remote(`/activities/${encodeURIComponent(targetId)}/state`)
  return request(`/activities/${encodeURIComponent(targetId)}/update`, "POST", {
    state: { message },
    expected_revision: snapshot.revision,
    idempotency_key: `delivery:${eventId}`,
  })
}

export function endDeliveryRequest(targetId, orderId) {
  return request(`/activities/${encodeURIComponent(targetId)}/end`, "POST", {
    idempotency_key: `delivery:${orderId}:end:1`,
  })
}
// Build a request, persist it in your business database, then call sendRemoteRequest.
// After a timeout, call sendRemoteRequest with that same persisted request.
// Do not rebuild it from a newer snapshot when retrying an uncertain request.
// After VERSION_CONFLICT, read again and decide whether the business event is still current.
```

## 限制与错误

JSON 请求体最多 64 KiB，小组件状态最多 16 KiB，活动完整转义后的 APNs 载荷最多 4 KiB。状态完整替换；通知和更新共用[每日推送额度](scripting://doc?title=Remote%20Updates%20Overview)。

错误为 `{ok:false,code,error?,details?,request_id?,timestamp?}`。HTTP 400 表示参数/schema/载荷错误，401 表示凭据无效或过期，403 表示权限不足或账户能力不可用，404 表示资源不可见，409 表示版本/幂等冲突或 token 未就绪，410 表示资源已撤销，429 表示额度或请求频率受限。检查 `code`：`VERSION_CONFLICT` 需要重新读取并判断业务，`IDEMPOTENCY_CONFLICT` 需要修正请求持久化，`TOKEN_PENDING` 需要等待登记，`PUSH_LIMIT_EXCEEDED` 需要可用的每日额度。不要因此反复创建新幂等键。

请求接受后查询操作进度。启动为 `unknown` 时使用同一次 launch 对账，不要再创建活动。重试保留相同幂等键和载荷；新业务生命周期才明确采用新的 generation。
