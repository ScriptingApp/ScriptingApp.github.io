# Main script sessions

ScriptSession and Storage are global APIs; neither needs an import. A main index.tsx or home_screen_default_ui.tsx registers a receiver. Other entries of the same script can request a reply, including supported App extensions in another process.

Start the main script first. It must still be running and have execution time to handle requests. This API does not launch, wake or keep the App alive.

## Main entry: index.tsx

```tsx
import { Navigation, Script, Text } from "scripting"

async function main() {
  // Replace this handler with your own validated application commands.
  const id = ScriptSession.register(async message => {
    return { accepted: true, message }
  })
  Storage.set("mainSessionID", id)
  try {
    await Navigation.present(<Text>Main session is running. Close to unregister.</Text>)
  } finally {
    ScriptSession.unregister(id)
    Storage.remove("mainSessionID")
    Script.exit()
  }
}

void main()
```

## Share extension entry: intent.tsx

Enable text input for this script in its settings and choose to run inside the share extension. Run the main entry, then share text from an App and choose this same script in Scripting's share extension.

```ts
import { Script } from "scripting"

async function main() {
  const id = Storage.get<string>("mainSessionID")
  if (!id) throw new Error("Start the main script first")
  try {
    const reply = await ScriptSession.request(id, { command: "status" }, { timeout: 5000 })
    Script.exit({ type: "text", value: JSON.stringify(reply) })
  } catch (error: any) {
    Script.exit({ type: "text", value: String(error.code ?? error.message) })
  }
}

void main()
```

## App Intent entry: app_intents.tsx

```ts
import { AppIntentManager, AppIntentProtocol } from "scripting"

export const StopMainIntent = AppIntentManager.register({
  name: "StopMainIntent",
  protocol: AppIntentProtocol.LiveActivityIntent,
  perform: async () => {
    const id = Storage.get<string>("mainSessionID")
    if (!id) throw new Error("Start the main script first")
    console.log(await ScriptSession.request(id, { command: "stop" }, { timeout: 5000 }))
  },
})
```

A command name has no built-in effect. Your main handler must implement the operation and return an acknowledgement. Return the reply before unregistering or exiting; otherwise pending requests are rejected.

## Limits and lifecycle

- Only the main App's index/home_screen session can register. Extensions can request a reply, but cannot register the main receiver. The extension must have access to Scripting's shared App Group; additional system restrictions of its extension type still apply.
- Each registration returns a fresh ID. IDs target that exact session of the same native script identity. Old IDs never select a replacement session.
- Same-process messages use the existing memory path; cross-process messages use shared storage. Notifications only prompt a check; they do not guarantee delivery time or wake a suspended App. A fallback scan handles missed notification hints while the process can run.
- At most 32 registered sessions and 32 pending requests per process. Input/reply are JSON-compatible, up to 64 KiB each. Handler undefined means a null reply. Functions, symbols, BigInt, nonfinite numbers, undefined fields and cyclic data are rejected.
- Reply timeout defaults to 10000 ms and accepts integer values from 100 to 30000. Expiry includes time spent suspended/asleep. Expired queued commands are discarded on resume. Timeout cannot preempt synchronous JS and does not undo work already accepted by the receiver.
- Unregister/exit removes the receiver and releases its callbacks. Sender exit cleans up pending requests; work already submitted to another process may have been accepted. Late replies are ignored. Missing/stale/unresponsive receivers fail with an explicit error or timeout; receiver restarts do not replay old requests.
- An acknowledgement confirms only what your handler reports. For example, a stop acknowledgement alone does not prove physical location restoration.

Error codes: SCRIPT_SESSION_UNAVAILABLE, SCRIPT_SESSION_NOT_FOUND, SCRIPT_SESSION_BUSY, SCRIPT_SESSION_CLOSED, SCRIPT_SESSION_TIMEOUT, SCRIPT_SESSION_INVALID_DATA, SCRIPT_SESSION_INVALID_HANDLER, SCRIPT_SESSION_HANDLER_FAILED, ERR_PRO_REQUIRED.
