# 主脚本会话通信

ScriptSession 和 Storage 都是全局 API，无需 import。主脚本 index.tsx 或 home_screen_default_ui.tsx 注册接收者，同一脚本的其他入口可发送请求并取得应答，包括在另一进程中运行且支持共享容器的扩展。

请先启动主脚本。主脚本必须仍在运行，并获得系统执行时间才能处理请求。该 API 不负责启动、唤醒或后台保活。

## 主入口：index.tsx

```tsx
import { Navigation, Script, Text } from "scripting"

async function main() {
  // 在这里校验并实现自己的应用命令。
  const id = ScriptSession.register(async message => {
    return { accepted: true, message }
  })
  Storage.set("mainSessionID", id)
  try {
    await Navigation.present(<Text>主会话运行中，关闭后注销。</Text>)
  } finally {
    ScriptSession.unregister(id)
    Storage.remove("mainSessionID")
    Script.exit()
  }
}

void main()
```

## 分享扩展入口：intent.tsx

在脚本设置中启用文本输入，并选择在分享扩展内运行。先启动主入口，再从 App 分享文本，进入 Scripting 分享扩展并选择同一脚本。

```ts
import { Script } from "scripting"

async function main() {
  const id = Storage.get<string>("mainSessionID")
  if (!id) throw new Error("请先启动主脚本")
  try {
    const reply = await ScriptSession.request(id, { command: "status" }, { timeout: 5000 })
    Script.exit({ type: "text", value: JSON.stringify(reply) })
  } catch (error: any) {
    Script.exit({ type: "text", value: String(error.code ?? error.message) })
  }
}

void main()
```

## App Intent 入口：app_intents.tsx

```ts
import { AppIntentManager, AppIntentProtocol } from "scripting"

export const StopMainIntent = AppIntentManager.register({
  name: "StopMainIntent",
  protocol: AppIntentProtocol.LiveActivityIntent,
  perform: async () => {
    const id = Storage.get<string>("mainSessionID")
    if (!id) throw new Error("请先启动主脚本")
    console.log(await ScriptSession.request(id, { command: "stop" }, { timeout: 5000 }))
  },
})
```

命令名称没有内置行为，需要主 handler 自行执行操作并返回应答。请先返回应答，再注销或退出主脚本，否则待应答请求会被拒绝。

## 限制与生命周期

- 仅主 App 的 index/home_screen 可注册接收者。扩展可发送请求，不可注册主会话；扩展需能访问 Scripting 的 App Group，仍受对应扩展类型的系统限制。
- 每次注册返回新 ID，只定位原生身份相同的脚本中该次会话，旧 ID 不会投递给替代会话。
- 同进程保留内存传递路径，跨进程使用共享存储。通知只提醒读取，不保证时延，也不能唤醒被挂起的 App；进程可执行时通过补偿扫描处理遗漏的通知。
- 每进程最多 32 个已注册会话、32 个待应答请求。输入和应答为 JSON，各最多 64 KiB；handler 返回 undefined 时应答为 null。函数、symbol、BigInt、非有限数、undefined 字段和循环引用会拒绝。
- 应答期限默认 10000 毫秒，可设 100...30000 的整数，计入挂起和设备休眠时间。恢复后丢弃过期排队命令；不能抢占同步 JS，也不会撤销接收方已接受的工作。
- 注销/退出会移除接收者并释放回调。发送方退出时清理待回应请求，但已提交到另一进程的工作可能已被接受；迟到回应会忽略。找不到、过期或不可响应的主会话会明确报错或超时，主 App 重启不重放旧命令。
- 应答仅证明 handler 所报告的结果，例如“停止”应答本身不能证明设备真实位置已恢复。

错误码：SCRIPT_SESSION_UNAVAILABLE、SCRIPT_SESSION_NOT_FOUND、SCRIPT_SESSION_BUSY、SCRIPT_SESSION_CLOSED、SCRIPT_SESSION_TIMEOUT、SCRIPT_SESSION_INVALID_DATA、SCRIPT_SESSION_INVALID_HANDLER、SCRIPT_SESSION_HANDLER_FAILED、ERR_PRO_REQUIRED。
