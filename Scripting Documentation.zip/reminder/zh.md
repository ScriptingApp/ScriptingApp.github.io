`Reminder` API 用于在 iOS 日历中创建、编辑和管理提醒事项。它支持通过 `DateComponents` 精确设置截止日期、指定优先级、添加备注、配置重复规则，并跟踪完成状态，适用于各种待办和日程提醒场景。

---

## 类：`Reminder`

`Reminder` 类提供用于操作单个提醒事项的属性和方法。

---

### 属性

* **`identifier: string`**
  系统分配的唯一标识符（只读）。

* **`calendar: Calendar`**
  提醒事项所属的日历对象。每个提醒必须关联一个日历。

* **`title: string`**
  提醒事项的标题或摘要。

* **`notes?: string`**
  可选备注信息，用于补充提醒详情。

* **`isCompleted: boolean`**
  是否已完成该提醒事项。

  * 设为 `true` 时，`completionDate` 将自动设为当前时间。
  * 设为 `false` 时，`completionDate` 将被清除为 `null`。

  **注意：** 如果提醒在其他设备或应用中完成，可能出现 `isCompleted` 为 `true`，但 `completionDate` 为 `null` 的情况。

* **`priority: number`**
  提醒事项的优先级，数值越高表示越紧急或重要。

* **`completionDate?: Date`**
  提醒事项的完成时间。

  * 设为具体时间将自动设置 `isCompleted = true`。
  * 设为 `null` 将取消完成状态。

* **`dueDateComponents?: DateComponents`**
  使用日期组件设置截止时间。支持部分指定日期或时间字段，适用于日程类或重复类提醒。

  **说明：** 可使用 `DateComponents.isValidDate` 检查当前组件组合是否为有效日期。

* **`dueDate?: Date`**
  **（已废弃）** 原用于设置截止时间的字段，请改用 `dueDateComponents`。

* **`dueDateIncludesTime: boolean`**
  **（已废弃）** 表示 `dueDate` 是否包含时间部分。当使用 `dueDateComponents` 时已不再需要。

* **`recurrenceRules?: RecurrenceRule[]`**
  可选的重复规则数组，用于配置定期重复的提醒任务。

* **`hasRecurrenceRules: boolean`**
  是否存在重复规则（只读）。

---

### 实例方法

* **`addRecurrenceRule(rule: RecurrenceRule): void`**
  向提醒中添加一个重复规则。

* **`removeRecurrenceRule(rule: RecurrenceRule): void`**
  从提醒中移除一个重复规则。

* **`remove(): Promise<void>`**
  从所属日历中删除该提醒事项。

* **`save(): Promise<void>`**
  保存提醒的修改。如果是新建提醒，将自动添加到指定日历中。

---

### 静态方法

* **`Reminder.getAll(calendars?: Calendar[]): Promise<Reminder[]>`**
  获取所有提醒事项。可选指定日历，若不指定则默认查询全部日历。

* **`Reminder.getIncompletes(options?: { startDate?: Date; endDate?: Date; calendars?: Calendar[] }): Promise<Reminder[]>`**
  获取指定时间范围内未完成的提醒事项。

  * **`startDate`**：仅包含截止时间在该时间之后的提醒。

  * **`endDate`**：仅包含截止时间在该时间之前的提醒。

  * **`calendars`**：可选指定要查询的日历数组。

  > 注意：此方法不会展开重复规则，只返回具有具体截止时间的基本提醒项。

* **`Reminder.getCompleteds(options?: { startDate?: Date; endDate?: Date; calendars?: Calendar[] }): Promise<Reminder[]>`**
  获取指定时间范围内已完成的提醒事项。

  * **`startDate`**：仅包含完成时间在该时间之后的提醒。
  * **`endDate`**：仅包含完成时间在该时间之前的提醒。
  * **`calendars`**：可选指定要查询的日历数组。

---

## 示例

### 使用日期组件创建提醒事项

```ts
const reminder = new Reminder()
reminder.title = "准备会议资料"
reminder.notes = "周一团队会议前完成"

reminder.dueDateComponents = new DateComponents({
  year: 2025,
  month: 10,
  day: 6,
  hour: 9,
  minute: 30
})

reminder.priority = 2
await reminder.save()
console.log(`提醒事项已创建：${reminder.title}`)
```

---

### 创建无时间的提醒事项

```ts
reminder.dueDateComponents = new DateComponents({
  year: 2025,
  month: 10,
  day: 6
})
```

---

### 从 Date 对象创建日期组件

```ts
const now = new Date()
reminder.dueDateComponents = DateComponents.fromDate(now)
```

---

### 获取所有提醒事项

```ts
const reminders = await Reminder.getAll()
for (const reminder of reminders) {
  console.log(`提醒事项：${reminder.title}`)
}
```

---

### 获取未完成的提醒事项

```ts
const incompletes = await Reminder.getIncompletes({
  startDate: new Date("2025-01-01"),
  endDate: new Date("2025-01-31")
})
```

---

### 标记提醒事项为已完成

```ts
reminder.isCompleted = true
await reminder.save()
```

---

### 删除提醒事项

```ts
await reminder.remove()
```

---

## 补充说明

* **关于日期管理**
  推荐使用 `dueDateComponents` 来设置截止时间，支持仅设定日期、设定完整时间，或指定特定时间字段。使用 `.isValidDate` 检查是否为有效日期组合。

* **关于重复规则**
  可通过 `addRecurrenceRule` 和 `removeRecurrenceRule` 方法为提醒添加或移除重复模式。
  查询方法不会自动展开重复实例。

* **关于筛选方法**
  `getIncompletes` 和 `getCompleteds` 仅返回原始提醒事项，不包括重复扩展项。

* **已废弃字段**

  * `dueDate` 和 `dueDateIncludesTime` 已不推荐使用，仅保留向后兼容。
  * 请统一使用 `dueDateComponents` 来处理提醒的日期逻辑。
