`SFTPClient` 类用于通过 SSH 连接访问远程文件系统，基于 SFTP 协议。它支持常见的文件操作，包括读取目录、管理文件与文件夹、获取文件属性、解析真实路径等。

该类实例通常由 `SSHClient.openSFTP()` 方法返回。

---

## 属性

### `readonly isActive: boolean`

指示当前 SFTP 连接是否仍然有效。

* `true`：连接仍然处于活跃状态。
* `false`：连接已关闭或中断。

---

## 方法

### `close(): Promise<void>`

关闭当前 SFTP 连接。

#### 返回值：

* `Promise<void>`：连接关闭成功时 resolve。

#### 示例：

```ts
await sftp.close()
```

---

### `readDirectory(atPath: string): Promise<string[]>`

读取指定目录下的文件和子目录名称。

#### 参数：

* `atPath`（字符串）：
  要读取的远程目录路径。

#### 返回值：

* 一个 `Promise`，resolve 为该目录下文件与子目录名称组成的字符串数组。

#### 示例：

```ts
const items = await sftp.readDirectory("/home/user")
```

---

### `createDirectory(atPath: string): Promise<void>`

在指定路径创建一个新目录。

#### 参数：

* `atPath`（字符串）：
  要创建目录的目标路径。

#### 返回值：

* 一个 `Promise`，创建成功时 resolve。

#### 示例：

```ts
await sftp.createDirectory("/home/user/new-folder")
```

---

### `removeDirectory(atPath: string): Promise<void>`

删除指定路径下的目录。

#### 参数：

* `atPath`（字符串）：
  要删除的目录路径。

#### 返回值：

* 一个 `Promise`，删除成功时 resolve。

#### 示例：

```ts
await sftp.removeDirectory("/home/user/old-folder")
```

---

### `rename(oldPath: string, newPath: string): Promise<void>`

重命名文件或目录。

#### 参数：

* `oldPath`（字符串）：
  原路径（要重命名的文件或目录）。

* `newPath`（字符串）：
  新路径（目标名称或位置）。

#### 返回值：

* 一个 `Promise`，操作成功时 resolve。

#### 示例：

```ts
await sftp.rename("/home/user/file.txt", "/home/user/file-renamed.txt")
```

---

### `getAttributes(atPath: string): Promise<{ ... }>`

获取文件或目录的元数据属性。

#### 参数：

* `atPath`（字符串）：
  要获取属性的文件或目录路径。

#### 返回值：

* 一个 `Promise`，resolve 为一个包含以下属性的对象：

  * `size?: number`：文件大小（字节）
  * `flag?: number`：内部标志位
  * `userId?: number`：所属用户 ID
  * `groupId?: number`：所属组 ID
  * `accessTime?: Date`：最后访问时间
  * `modificationTime?: Date`：最后修改时间
  * `permissions?: number`：Unix 权限（如 `0o755`）

#### 示例：

```ts
const attrs = await sftp.getAttributes("/home/user/file.txt")
```

---

### `readFile(atPath: string): Promise<string>`

读取指定文件的内容，作为字符串返回。

#### 参数：

* `atPath`（字符串）：
  要读取的文件路径。

#### 返回值：

* 一个 `Promise`，resolve 为文件的 UTF-8 字符串内容。

#### 示例：

```ts
const content = await sftp.readFile("/home/user/notes.txt")
```

---

### `writeFile(atPath: string, content: string): Promise<void>`

将内容写入指定路径的文件中（会覆盖原文件）。

#### 参数：

* `atPath`（字符串）：
  要写入的文件路径。

* `content`（字符串）：
  写入的文本内容。

#### 返回值：

* 一个 `Promise`，写入成功时 resolve。

#### 示例：

```ts
await sftp.writeFile("/home/user/todo.txt", "Buy milk")
```

---

### `removeFile(atPath: string): Promise<void>`

删除指定路径的文件。

#### 参数：

* `atPath`（字符串）：
  要删除的文件路径。

#### 返回值：

* 一个 `Promise`，删除成功时 resolve。

#### 示例：

```ts
await sftp.removeFile("/home/user/todo.txt")
```

---

### `getRealPath(atPath: string): Promise<string>`

获取指定路径的真实（绝对）路径，可解析符号链接或相对路径。

#### 参数：

* `atPath`（字符串）：
  要解析的路径，可以是 `~`、`.` 或包含符号链接。

#### 返回值：

* 一个 `Promise`，resolve 为解析后的绝对路径字符串。

#### 示例：

```ts
const realPath = await sftp.getRealPath("~/logs")
```

---

## 使用示例

```ts
const ssh = await SSHClient.connect({
  host: "192.168.1.10",
  authenticationMethod: SSHAuthenticationMethod.passwordBased("user", "pass")
})

const sftp = await ssh.openSFTP()

const files = await sftp.readDirectory("/home/user")
console.log("远程文件列表:", files)

await sftp.writeFile("/home/user/hello.txt", "Hello from Scripting app")
const content = await sftp.readFile("/home/user/hello.txt")
console.log("文件内容:", content)

await sftp.close()
```
